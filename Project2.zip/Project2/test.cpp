//
//  test.cpp
//  Project 2
//
//  Created by Anica Wang on 1/25/21.
//

#include <stdio.h>
#include "Sequence.h"
#include <type_traits>
#include <iostream>
#include <cassert>

using namespace std;

//#define CHECKTYPE(c, f, r, a)  \
//    {  \
//     static_assert(std::is_same<decltype(&c::f), r (c::*)a>::value, \
//         "You did not declare " #c "::" #f " as the spec does");  \
//     r (c::*p) a = &c::f;  \
//     (void) p;  \
//    }
//#define CHECKTYPENONMEMBER(f, r, a)  \
//    {  \
//     static_assert(std::is_same<decltype(&f), r (*)a>::value, \
//         "You did not declare " #f " as the spec does");  \
//     r (*p) a = f;  \
//     (void) p;  \
//    }
//
//static_assert(std::is_default_constructible<Sequence>::value,
//    "Sequence must be default-constructible.");
//static_assert(std::is_copy_constructible<Sequence>::value,
//    "Sequence must be copy-constructible.");
//static_assert(std::is_copy_assignable<Sequence>::value,
//    "Sequence must be assignable.");
//
//void thisFunctionWillNeverBeCalled()
//{
//    CHECKTYPE(Sequence, empty, bool, () const);
//    CHECKTYPE(Sequence, size, int, () const);
//    CHECKTYPE(Sequence, erase, bool, (int));
//    CHECKTYPE(Sequence, remove, int, (const ItemType&));
//    CHECKTYPE(Sequence, get, bool, (int, ItemType&) const);
//    CHECKTYPE(Sequence, set, bool, (int, const ItemType&));
//    CHECKTYPE(Sequence, find, int, (const ItemType&) const);
//    CHECKTYPE(Sequence, swap, void, (Sequence&));
//    CHECKTYPENONMEMBER(subsequence, int, (const Sequence&, const Sequence&));
//    CHECKTYPENONMEMBER(interleave, void, (const Sequence&, const Sequence&, Sequence&));
//    { auto p = static_cast<int (Sequence::*)(int, const ItemType&)>(&Sequence::insert); (void) p; }
//    { auto p = static_cast<int (Sequence::*)(const ItemType&)>(&Sequence::insert); (void) p; }
//}

//STRINGS

//void test()
//{
//    Sequence s;
//    assert(s.insert(0, "lavash") == 0);
//    assert(s.insert(0, "tortilla") == 0);
//    assert(s.size() == 2);
//    ItemType x = "injera";
//    assert(s.get(0, x)  &&  x == "tortilla");
//    assert(s.get(1, x)  &&  x == "lavash");
//}
//
//int main()
//{
//    test();
//    cout << "Passed all tests" << endl;
//}
//

//UNSIGNED LONG
//void test()
//{
//    Sequence s;
//    assert(s.insert(0, 10) == 0);
//    assert(s.insert(0, 20) == 0);
//    assert(s.size() == 2);
//    ItemType x = 999;
//    assert(s.get(0, x)  &&  x == 20);
//    assert(s.get(1, x)  &&  x == 10);
//}
//
//int main()
//{
    //test();
//    cout << "Passed all tests" << endl;
//}

int main()
{
//    Sequence s;
//    assert(s.empty() == 1);
//    assert(s.size() == 0);
//    assert(s.erase(0) == 0);
//    assert(s.remove(20) == 0);
//    s.insert(0, 100);
//    assert(s.insert(5, 100) == -1);
//    assert(s.erase(0) == 1);
//    assert(s.insert(0, 100) == 0);
//    s.insert(0, 200);
//    s.insert(2, 250);
//    s.insert(1, 150);
//    assert(s.insert(50) == 0);
//    s.insert(100);
//    assert(s.find(100) == 1);
//    assert(s.erase(0) == 1);
//    assert(s.remove(100) == 2);
//    assert(s.size() == 3 && s.find(150) == 1);
//    assert(s.find(100) == -1);
//
//    Sequence t;
//    t.insert(0, 100);
//    t.insert(100);
//    t.insert(25);
//    t.insert(2, 85);
//    t.insert(2, 100);
//    assert(t.remove(100) == 3);
//    ItemType temp;
//    assert(t.get(0, temp) == 1 && temp == 25);
//    assert(t.get(4, temp) == 0);
//    temp = 100;
//    assert(t.set(2, temp) == 0 && t.set(1, temp) == 1 && t.find(100) == 1);
//
//    Sequence q(s);
//    assert(q.size() == 3 && s.find(200) == 0 && s.find(250) == 2);
//    Sequence r;
//    r = t;
//    assert(r.size() == 2 && r.find(25) == 0 && r.find(100) == 1);
//    //
//    Sequence c;
//    c.insert(1);
//    c.insert(3);
//    c.insert(5);
//
//    Sequence d;
//    d.insert(2);
//    d.insert(4);
//    d.insert(6);
//
//    Sequence e;
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//    e.insert(0);
//
//    interleave(c, d, e);
//    assert(e.find(6) == 5 && e.find(0) == -1);
//    assert(c.size() == 3 && d.size() == 3 && e.size() == 6);
//    c.insert(7);
//    c.insert(8);
//    c.insert(9);
//
//    Sequence i(c);
//    Sequence j(c);
//    j = d;
//    interleave(i, j, j);
//    assert(j.find(9) == 8 && j.find(2) == 1 && j.find(3) == 2 && j.find(6) == 5 && j.find(7) == 6);
//    assert(j.size() == 9);
//
//    interleave(c, d, c);
//    assert(c.find(9) == 8 && c.find(2) == 1 && c.find(3) == 2 && c.find(6) == 5 && c.find(7) == 6);
//    assert(c.size() == 9);
//    Sequence k;
//    interleave(k, c, e);
//    //
//    Sequence a;
//    a.insert(1);
//    a.insert(2);
//    a.insert(3);
//    a.insert(3, 1);
//    a.insert(4, 2);
//    //a.dump();
//
//    Sequence b;
//    b.insert(1);
//    b.insert(2);
//    //b.dump();
//
//    assert(subsequence(a, b) == 0);
//    assert(subsequence(a, a) == 0);
//    //
//    Sequence f;
//    f.insert(0, 30);
//    f.insert(1, 21);
//    f.insert(2, 63);
//    f.insert(3, 42);
//    f.insert(4, 17);
//    f.insert(5, 63);
//    f.insert(6, 17);
//    f.insert(7, 29);
//    f.insert(8, 8);
//    f.insert(9, 32);
//
//    Sequence g;
//    g.insert(0, 63);
//    assert(subsequence(f, g) == 2);
//    g.insert(1, 17);
//    g.insert(2, 29);
//
//    Sequence h;
//    assert(subsequence(f, h) == -1);
//    assert(subsequence(h, f) == -1);
//    h.insert(0, 17);
//    h.insert(1, 63);
//    h.insert(2, 29);
//
//    assert(subsequence(f, g) == 5);
//    assert(subsequence(g, f) == -1);
//    assert(subsequence(g, h) == -1);
//    assert(subsequence(f, h) == -1);
//    cout << "All tests passed!" << endl;

    //test the constructor
        Sequence s1;
        //test that list is empty when created
        assert(s1.size() == 0);
        //test that empty function works
        assert(s1.empty() == 1);
        //test that 2 parameter insert function works correctly
        s1.insert(0, "apple");
        s1.insert(1, "banana");
        s1.insert(2, "carrot");
        s1.insert(3, "elephant");
        //test that 1 parameter insert function works correctly
        s1.insert("dog");
        //test that find function works correctly and that items were properly inserted
        assert(s1.find("dog") == 3);
        assert(s1.find("elephant") == 4);
        assert(s1.find("carrot") == 2);
        assert(s1.empty() == 0);
        assert(s1.size() == 5);
        //test that erase function works correctly
        s1.erase(0);
        s1.erase(3);
        //test that find function works correctly and that items were properly removed
        assert(s1.find("banana") == 0);
        assert(s1.find("dog") == 2);
        assert(s1.find("carrot") == 1);
        //test the get function
        ItemType temp;
        assert(s1.get(0, temp) == 1 && temp == "banana");
        //test that getting out of bounds is invalid
        assert(s1.get(3, temp) == 0);
        //test that items were properly removed
        assert(s1.find("apple") == -1);
        assert(s1.find("elephant") == -1);
        //test the set function
        s1.set(0, "basketball");
        assert(s1.find("banana") == -1);
        //make sure items not in list are not accidentally changed
        s1.set(3, "rando");
        assert(s1.find("rando") == -1);
        //test insertion at the end
        s1.insert(3, "egg");
        assert(s1.find("egg") == 3);
        assert(s1.find("dog") == 2);
        s1.insert("amazing");
        //make sure elements are in the correct order
        assert(s1.find("amazing") == 0);
        assert(s1.find("basketball") == 1);
        assert(s1.find("carrot") == 2);
        assert(s1.find("dog") == 3);
        assert(s1.find("egg") == 4);
        assert(s1.size() == 5);
        Sequence s2;
        s2.insert("fries");
        s2.insert("goat");
        s2.insert("zebra");
        s2.insert("pony");
        s2.insert("horse");
        //test that all elements were inserted in correct order
        assert(s2.find("fries") == 0);
        assert(s2.find("goat") == 1);
        assert(s2.find("horse") == 2);
        assert(s2.find("pony") == 3);
        assert(s2.find("zebra") == 4);
        //test that elements are not alphabetical if 2 parameter insert is used
        s2.insert(5, "arabian");
        assert(s2.find("arabian") == 5);
        s2.insert(6, "rando");
        s2.insert(0, "idk");
        //test that elements are in the correct order
        assert(s2.find("fries") == 1);
        assert(s2.find("idk") == 0);
        assert(s2.find("rando") == 7);
        assert(s2.find("arabian") == 6);
        assert(s2.find("goat") == 2);
        //swap function
        s1.swap(s2);
        //test that elements were correctly swapped, even with different sizes
        assert(s1.find("idk") == 0);
        assert(s1.find("fries") == 1);
        assert(s1.find("goat") == 2);
        assert(s1.find("horse") == 3);
        assert(s1.find("pony") == 4);
        assert(s1.find("zebra") == 5);
        assert(s1.find("arabian") == 6);
        assert(s1.find("rando") == 7);
        //test that other sequence was swapped correctly
        assert(s2.find("amazing") == 0);
        assert(s2.find("basketball") == 1);
        assert(s2.find("carrot") == 2);
        assert(s2.find("dog") == 3);
        assert(s2.find("egg") == 4);
        Sequence s3;
        s3.insert("dog");
        s3.insert("egg");
        //test the subsequence method
        assert(subsequence(s3, s2)  == -1);
        assert(subsequence(s2, s3) == 3);
        assert(subsequence(s2, s1) == -1);
        assert(subsequence(s1, s2) == -1);
        //test the copy constructor
        Sequence s4(s3);
        Sequence s5(s3);
        assert(s4.find("dog") == 0);
        assert(s4.find("egg") == 1);
        assert(s5.find("dog") == 0);
        assert(s5.find("egg") == 1);
        //test the assignment operator
        s5 = s2;
        assert(s5.find("amazing") == 0);
        assert(s5.find("basketball") == 1);
        assert(s5.find("carrot") == 2);
        assert(s5.find("dog") == 3);
        assert(s5.find("egg") == 4);
        assert(s4.find("dog") == 0);
        assert(s4.find("egg") == 1);
        //test the interleave function in the face of aliasing
        interleave (s5, s4, s5);
        assert(s5.find("amazing") == 0);
        assert(s5.find("dog") == 1);
        assert(s5.find("basketball") == 2);
        assert(s5.find("egg") == 3);
        assert(s5.find("carrot") == 4);
        assert(s5.size() == 7);
        //test the interleave function without aliasing
        interleave(s1, s2, s3);
        assert(s3.find("idk") == 0);
        assert(s3.find("amazing") == 1);
        assert(s3.find("fries") == 2);
        assert(s3.find("basketball") == 3);
        assert(s3.find("goat") == 4);
        assert(s3.find("carrot") == 5);
        assert(s3.find("horse") == 6);
        assert(s3.find("dog") == 7);
        assert(s3.find("pony") == 8);
        assert(s3.find("egg") == 9);
        assert(s3.find("zebra") == 10);
        assert(s3.find("arabian") == 11);
        assert(s3.find("rando") == 12);
    cout << "All tests passed." << endl;

}
