//
//  Sequence.cpp
//  Project 2
//
//  Created by Anica Wang on 1/20/21.
//

#include "Sequence.h"
#include <iostream>
#include <cstdlib>

Sequence::Sequence()
//create an empty sequence with no items
{
    //initialize head node linked to itself (dummy node)
    head = new Node();
    head->next = head;
    head->prev = head;
}

Sequence::~Sequence()
//destructor for sequence
{
    //initialize temporary pointer
    Node* temp = head->next;
    
    //loop thru linked list
    while (temp != head)
    {
        //initialize deletion pointer to next item
        Node* del = temp->next;
        //delete object temporary pointer is pointing to
        delete temp;
        //reset temporary pointer
        temp = del;
    }
    //delete head node
    delete head;
}

Sequence::Sequence(const Sequence& old)
//copy constructor for sequence
{
    //make a new head node linked to itself (dummy node)
    head = new Node;
    head->next = head;
    head->prev = head;
    
    //iterator to loop through old list
    Node* temp = old.head->next;
    for (int i = 0; i < old.size() && temp != old.head; i++)
    {
        //insert every value in old list to new list
        insert(i, temp->value);
        //increment iterator
        temp = temp->next;
    }
}

Sequence &Sequence::operator= (const Sequence &src)
//assignment operator
{
    //check aliasing
    if (this != &src)
    {
        //copy and swap
        Sequence temp = src;
        swap(temp);
    }
    return *this;
}

bool Sequence::empty() const
// Return true if the sequence is empty, otherwise false.
{
    //check if head pointers point to itself
    if (head->next == head && head->prev == head)
    {
        return true;
    }
    return false;
}

int Sequence::size() const
// Return the number of items in the sequence.
{
    //size counter
    int m_size = 0;
    //temporary iterator
    Node* temp = head->next;
    //loop through linked list
    while (temp != head)
    {
        //increment size and iterator
        m_size++;
        temp = temp->next;
    }
    return m_size;
}

int Sequence::insert(int pos, const ItemType& value)
    // Insert value into the sequence so that it becomes the item at
    // position pos.  The original item at position pos and those that
    // follow it end up at positions one higher than they were at before.
    // Return pos if 0 <= pos <= size() and the value could be
    // inserted.  (It might not be, if the sequence has a fixed capacity,
    // e.g., because it's implemented using a fixed-size array.)  Otherwise,
    // leave the sequence unchanged and return -1.  Notice that
    // if pos is equal to size(), the value is inserted at the end.
{
    //if valid position
    if (pos >= 0 && pos <= size())
    {
        //using counter and temporary node pointer
        int n = pos;
        Node* temp = head->next;
        //loop through items until pos is reached
        while (temp != head && n != 1)
        {
            temp = temp->next;
            n--;
        }
        //insert new node
        Node* p = new Node();
        //assign value
        p->value = value;
        //adjust p's pointers
        p->next = temp->next;
        p->prev = temp;
        //adjust temp's pointers
        temp->next->prev = p;
        temp->next = p;
        return pos;
    }
    //insert unsuccessful
    return -1;
}

int Sequence::insert(const ItemType& value)
    // Let p be the smallest integer such that value <= the item at
    // position p in the sequence; if no such item exists (i.e.,
    // value > all items in the sequence), let p be size().  Insert
    // value into the sequence so that it becomes the item in position
    // p.  The original item at position p and those that follow it end
    // up at positions one higher than before.  Return p if the value
    // was actually inserted.  Return -1 if the value was not inserted
    // (perhaps because the sequence has a fixed capacity and is full).
{
    //int to track position
    int p = 0;
    //node pointer counter
    Node* temp = head->next;
    //loop through sequence
    while (temp != head && value > temp->value)
    {
        //increment pointer and counter
        temp = temp->next;
        p++;
    }
    //insert at position and return
    return insert(p, value);
}
    
bool Sequence::erase(int pos)
    // If 0 <= pos < size(), remove the item at position pos from
    // the sequence (so that all items that followed that item end up at
    // positions one lower than they were at before), and return true.
    // Otherwise, leave the sequence unchanged and return false.
{
    //if valid position
    if (pos >= 0 && pos < size())
    {
        //using counter and temporary node pointer
        int n = pos;
        Node* temp = head->next;
        //loop through sequence until position pos is reached
        while (temp != head && n != 1)
        {
            temp = temp->next;
            n--;
        }
        //make new node pointer pointing to item to be deleted
        Node* del = temp->next;
        //adjust temp's pointers
        temp->next = del->next;
        //adjust del's pointers
        del->next->prev = temp;
        //delete element
        delete del;
        return true;
    }
    return false;
}

int Sequence::remove(const ItemType& value)
    // Erase all items from the sequence that == value.  Return the
    // number of items removed (which will be 0 if no item == value).
{
    //count of number of elements removed
    int n = 0;
    //temporary iterator
    Node* temp = head->next;
    //loop through sequence
    for (int i = 0; temp != head; i++)
    {
        //if values match
        if (temp->value == value)
        {
            //adjust temp pointer
            temp = temp->next;
            //remove item
            erase(i);
            //decrement index
            i--;
            //increment number of elements removed
            n++;
        }
        //otherwise keep looking
        else
        {
            temp = temp->next;
        }
    }
    return n;
}

bool Sequence::get(int pos, ItemType& value) const
    // If 0 <= pos < size(), copy into value the item at position pos
    // of the sequence and return true.  Otherwise, leave value unchanged
    // and return false.
{
    //if valid position
    if (pos >= 0 && pos < size())
    {
        //temporary node pointer to iterate through sequence
        Node* temp = head->next;
        //continue until position pos reached
        while (temp != head && pos > 0)
        {
            //increment pointer and decrement position
            temp = temp->next;
            pos--;
        }
        //retrieve value at position pos
        value = temp->value;
        return true;
    }
    return false;
}

bool Sequence::set(int pos, const ItemType& value)
    // If 0 <= pos < size(), replace the item at position pos in the
    // sequence with value and return true.  Otherwise, leave the sequence
    // unchanged and return false.
{
    //if valid position
    if (pos >= 0 && pos < size())
    {
        //temporary node pointer to iterate through sequence
        Node* temp = head->next;
        //continue until position pos reached
        while (temp != head && pos > 0)
        {
            //increment pointer and decrement position
            temp = temp->next;
            pos--;
        }
        //update value at position pos
        temp->value = value;
        return true;
    }
    return false;
}

int Sequence::find(const ItemType& value) const
    // Let p be the smallest integer such that value == the item at
    // position p in the sequence; if no such item exists, let p be -1.
    // Return p.
{
    //node pointer to iterate through sequence
    Node* temp = head->next;
    for (int i = 0; temp != head; i++)
    {
        //if values match
        if (temp->value == value)
        {
            //return position
            return i;
        }
        //otherwise keep looking
        temp = temp->next;
    }
    //value not found
    return -1;
}

void Sequence::swap(Sequence& other)
    // Exchange the contents of this sequence with the other one.
{
    //create temporary pointer
    Node* temp = head;
    //swap head pointers
    head = other.head;
    other.head = temp;
}

//void Sequence::dump() const
//{
//    Node* temp = head->next;
//    
//    while (temp != head)
//    {
//        std::cout << temp->value << std::endl;
//        temp = temp->next;
//    }
//    return;
//}

int subsequence(const Sequence& seq1, const Sequence& seq2)
//Consider all the items in seq2; let's call them seq20, seq21, ..., seq2n. If there exists at least one k such that seq1k == seq20 and seq1k+1 == seq21 and ... and seq1k+n == seq2n, and k+n < seq1.size(), then this function returns the smallest such k. (In other words, if seq2 is a consecutive subsequence of seq1, the function returns the earliest place in seq1 where that subsequence starts.) If no such k exists or if seq2 is empty, the function returns -1.
{
    //determine size of both sequences
    int size1 = seq1.size();
    int size2 = seq2.size();
    //loop through sequence 1
    for (int pos = 0; pos < size1; pos++)
    {
        //temporary holders for items in sequences
        ItemType item1;
        ItemType item2;
        //separate index for sequence 2
        int i = 0;
        //get values in each sequence
        seq1.get(pos, item1);
        seq2.get(i, item2);
        //if values match
        if (item1 == item2)
        {
            //keep looking in next position
            int a = pos + 1;
            //loop through both sequences
            for (i = 1; i < size2 && a < size1; i++)
            {
                //obtain values
                seq1.get(a, item1);
                seq2.get(i, item2);
                //once an item does not equal the other
                if (item1 != item2)
                {
                    //keep searching sequence 1
                    break;
                }
                //if equal, keep comparing
                a++;
            }
            //if all values match (is valid subsequence)
            if (i == size2)
            {
                return pos;
            }
        }
        
    }
    //subsequence not found or sequence is empty
    return -1;
}

void interleave(const Sequence& seq1, const Sequence& seq2, Sequence& result)
//This function produces as a result a sequence that consists of the first item in seq1, then the first in seq2, then the second in seq1, then the second in seq2, etc.
{
    //temporary sequence, size of each sequence, and counters for each sequence
    Sequence temp;
    int size1 = seq1.size();
    int size2 = seq2.size();
    int p1 = 0;
    int p2 = 0;
    int p3 = 0;
    //loop through both sequences
    while (p1 < size1 + size2)
    {
        //temporary holders for items in each sequence
        ItemType one;
        ItemType two;
        //insert element from seqence 1
        if (seq1.get(p2, one))
        {
            temp.insert(p1, one);
            p1++;
        }
        //insert element from sequence 2
        if (seq2.get(p3, two))
        {
            temp.insert(p1, two);
            p1++;
        }
        //keep looping until end
        p2++;
        p3++;
    }
    //to account for it result and one of the substrings point to the same
    temp.swap(result);
}
    
