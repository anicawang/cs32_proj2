//
//  Sequence.hpp
//  Project 2
//
//  Created by Anica Wang on 1/20/21.
//

#ifndef Sequence_h
#define Sequence_h

#include <iostream>
#include <string>

using ItemType = std::string;

class Sequence
{
  public:
    Sequence();
    ~Sequence();
    Sequence(const Sequence& old);
    Sequence &operator= (const Sequence &src);
    bool empty() const;
    int size() const;
    int insert(int pos, const ItemType& value);
    int insert(const ItemType& value);
    bool erase(int pos);
    int remove(const ItemType& value);
    bool get(int pos, ItemType& value) const;
    bool set(int pos, const ItemType& value);
    int find(const ItemType& value) const;
    void swap(Sequence& other);
    //void dump() const;
    
 private:
    struct Node
    {
        ItemType value;
        Node* next;
        Node* prev;
    };
    Node* head;
};

void interleave(const Sequence& seq1, const Sequence& seq2, Sequence& result);
int subsequence(const Sequence& seq1, const Sequence& seq2);

#endif /* Sequence_h */
